package com.wipro.selenium;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.ui.Select;

public class Sel_4 {
	
	//Question No 4

	public static void main(String[] args) throws Exception {
	
		//initializing and setting up the Web driver
		WebDriver driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		
		//Maximizing the window 
		driver.manage().window().maximize();
		
		//STEP 1:
		//using below link for Opencart
		driver.get("http://10.207.182.108:81/opencart/");
		
		driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/']")).click();
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
		
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		
		//STEP 2:
		//clicking on login link
		//driver.findElement(By.xpath("//span[contains(text(),'My Account') and @class='hidden-xs hidden-sm hidden-md']")).click();
		driver.findElement(By.xpath("//a[@href='http://10.207.182.111:84/opencart/index.php?route=account/login']")).click();

		
		//STEP 3:
		//Enter Email Address and Password and click on "Login" Button
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("vishu@gmail.com");
		driver.findElement(By.name("password")).sendKeys("opencart234");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		
		//STEP 4:
		//searching the product and Enter(no click)
		driver.findElement(By.name("search")).sendKeys("Apple");
		Keyboard kb=((HasInputDevices)driver).getKeyboard();
		kb.pressKey(Keys.ENTER);
		
		
		//STEP 5:
		//finding monitors from component list
		driver.findElement(By.name("category_id")).click();
		Select component= new Select(driver.findElement(By.name("category_id")));
		component.selectByValue("28");
		//click on search in sub categories
		driver.findElement(By.name("sub_category")).click();
		//click on search
		driver.findElement(By.id("button-search")).click();
		
		
		//STEP 6:
		//Click on "Phones and PDA's" tab
		driver.findElement(By.xpath("//a[@href='http://10.207.182.111:84/opencart/index.php?route=product/category&path=24']")).click();
		
		
		//STEP 7:
		//Sort from the "Price (High > Low)" for the page
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div[3]/select")).click();
		Select price=new Select(driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div[3]/select")));
		price.selectByValue("http://10.207.182.111:84/opencart/index.php?route=product/category&path=24&sort=p.price&order=DESC");
		
		
		//STEP 8:
		//Click on "Add to Compare " for the first three phones" and click on Close button 
		 driver.findElement(By.xpath("//*[@id=\"content\"]/div[4]/div[1]/div[1]/div[3]/a")).click();
		Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id=\"content\"]/div[4]/div[2]/div[1]/div[3]/a")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id=\"content\"]/div[4]/div[3]/div[1]/div[3]/a")).click();
		
		 Thread.sleep(5000);
		 
		 //STEP 9:
		 //Click on "Product Compare"
		 //driver.findElement(By.id("compare-total")).click();
		 driver.findElement(By.cssSelector("#compare-total")).click();
		//driver.findElement(By.xpath("//*[@id=\"content\"]/table/tbody[1]/tr[1]/td[2]/a")).click();
		
		 //STEP 10:
		 //Click on the first phone link on the page
		 //driver.findElement(By.xpath("//a[@href='http://10.207.182.111:84/opencart/index.php?route=product/product&product_id=29']")).click();
		 //driver.findElement(By.xpath("//a[contains(text(),'Palm Treo Pro')]")).click();
		 driver.findElement(By.xpath("//*[@id=\"content\"]/table/tbody[1]/tr[1]/td[2]/a")).click();
		 
		 //STEP 11:
		 //Check the fifth feature in the description section of the phone and write into flat file. 
		 //Getting the 5th feature
		 String str=driver.findElement(By.xpath("//*[@id=\"tab-description\"]/ul/li[5]")).getText();
		 
		 //writing it into file
		 FileWriter fr=new FileWriter(System.getProperty("user.dir")+"//sel2_file");
		 BufferedWriter br=new BufferedWriter(fr);
		 br.write(str);
		 br.newLine();
		 br.close();
		 
	
		 //STEP 12:
		 //Click on "Add to Cart"
		 driver.findElement(By.id("button-cart")).click();
		 Thread.sleep(10000);
		 
		 //STEP 13:
		 //Click on "Shopping Cart" displayed on ribbon message 
		 driver.findElement(By.cssSelector("#header > div.links > a:nth-child(4)")).click();
		 
		 Thread.sleep(5000);
		 //STEP 14
		 //Click on Check out button
		 driver.findElement(By.cssSelector("#content > div.buttons > div.right > a")).click();
		 Thread.sleep(5000);
		
		 
		 //STEP 15:
		 //Click on Continue buttons (2nd, 3rd and 4th)
		 driver.findElement(By.xpath("//*[@id='button-payment-address']")).click();
		 Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id='button-shipping-address']")).click();
		 Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id='button-shipping-method']")).click();
		 Thread.sleep(5000);
		
		
		//STEP 16:
		//Check the Terms and Conditions Checkbox and click Continue
		driver.findElement(By.xpath("//input[@type='checkbox']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='button-payment-method']")).click();
		Thread.sleep(5000);
		
		
		//STEP 17:
		//Click Confirm Order
		driver.findElement(By.xpath("//*[@id='button-confirm']")).click();

		//STEP 18:
		//Click on browser Back button
		driver.navigate().back();
		
		//STEP 19:
		//Click on "Order history " from "My account "tab
		driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/index.php?route=account/account']")).click();
		driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/index.php?route=account/order']")).click(); 
		Thread.sleep(1000);
		
		
		//STEP 20:
		//Click on "Subscribe to news letters"
		driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/index.php?route=account/newsletter']")).click();
		driver.findElement(By.xpath("//*[@type='radio' and @value='1']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@value='Continue' and @type='submit']")).click();
		
		
		//STEP 21:
		//Click on Extras -> Specials in the footer 
		driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/index.php?route=product/special']")).click();
		
		
		//STEP 22:
		//Click on List (or) Grid whichever is enabled
		driver.findElement(By.xpath("//*[contains(text(),'Grid')]")).click();
		
		
		//STEP 23:
		//Click on "Logout "
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/index.php?route=account/logout']")).click();
		driver.findElement(By.xpath("//*[contains(text(),'Continue')]")).click();
	}

}
