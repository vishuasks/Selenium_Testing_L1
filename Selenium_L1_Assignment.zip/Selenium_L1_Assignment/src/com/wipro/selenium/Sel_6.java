package com.wipro.selenium;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.ui.Select;

public class Sel_6 {
	//Junit utilization program
	
	public static WebDriver driver;
	
	public String str;
	
	@BeforeClass
	public static void set_up()
	{
		driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		//Maximizing the window 
		driver.manage().window().maximize();
	}
	
	@Before
	public void launch()
	{
		//STEP 1:
		// Launching the Website
		driver.get("http://10.207.182.108:81/opencart/");
		
		driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/']")).click();
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
		
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}

	@Test
	public void Login() throws Exception
	{
		//STEP 2:
		//clicking on login link
		driver.findElement(By.xpath("//a[@href='http://10.207.182.111:84/opencart/index.php?route=account/login']")).click();
		
		//STEP 3:
		//Enter Email Address and Password and click on "Login" Button
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("vishu@gmail.com");
		driver.findElement(By.name("password")).sendKeys("opencart234");
		driver.findElement(By.xpath("//input[@type='submit']")).click();

		//STEP 4:
		//Searching a product
		driver.findElement(By.name("search")).sendKeys("Canon");
		Keyboard kb=((HasInputDevices)driver).getKeyboard();
		kb.pressKey(Keys.ENTER);
		
		Thread.sleep(5000);
		//STEP 5:
		//clicking on the "Canon" image icon
		driver.findElement(By.cssSelector("#content > div.product-list > div > div.left > div.image > a > img")).click();
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"option-226\"]/select")).click();
		Select sel=new Select(driver.findElement(By.xpath("//*[@id=\"option-226\"]/select")));
		sel.selectByValue("15");
		
		
		//STEP 6:
		//changing the quantity
		driver.findElement(By.name("quantity")).clear();
		driver.findElement(By.name("quantity")).sendKeys("2");
		
		//STEP 7:
		//Click on Add to cart button
		Thread.sleep(5000);
		driver.findElement(By.id("button-cart")).click();
		
		
		//STEP 8:
		//clicking on shopping cart
		driver.findElement(By.cssSelector("#header > div.links > a:nth-child(4)")).click();
	
		//STEP 9:
		//fetching total value to a flat file
		str=driver.findElement(By.xpath("//*[@id='total']/tbody/tr[2]/td[2]")).getText();
		String s=str.substring(1,str.length());
		float f=Float.valueOf(s);
		
		
		//STEP 10:
		// Total will stored in storage file
		 FileWriter fr=new FileWriter(System.getProperty("user.dir")+"//junit_file");
		 BufferedWriter br=new BufferedWriter(fr);
		 br.newLine();
		 br.write(str);
		 br.newLine();
		 br.close();
	
	
	
		 if(f<200.00)
		 {
			 driver.findElement(By.cssSelector("#content > div.buttons > div.center > a")).click();
			 
		 }
	 
		 else
		 {
			driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/index.php?route=account/logout']")).click();
			driver.findElement(By.xpath("//*[contains(text(),'Continue')]")).click();
		 }
	}
		 
		 
		 @After
		 public void continues()
		 {
			 System.out.println("Total price:"+str);
		 }
		 
		 @AfterClass 
		 public static void ending()
		 {
			 driver.close();
		 }

}
