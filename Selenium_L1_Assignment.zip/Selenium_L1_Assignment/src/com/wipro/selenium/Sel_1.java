package com.wipro.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sel_1 {
	
	//Question No 1

			public static void main(String[] args) throws IOException {
		
			//initializing and setting up the Web driver
			WebDriver driver=new ChromeDriver();
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			
			//Maximizing the window 
			driver.manage().window().maximize();
			
			//Specifying the excel file and importing it
			File filepath=new File(System.getProperty("user.dir")+"//xcel.xlsx");
			
			FileInputStream fiss= new FileInputStream(filepath);
			
			XSSFWorkbook wbook= new XSSFWorkbook(fiss);
			
			XSSFSheet sheet= wbook.getSheet("Opencart");
			
			//calculating row and column count
			int row=sheet.getLastRowNum();
			//int col=sheet.getRow(1).getLastCellNum();
			
			//launching the website
			driver.get("http://10.207.182.108:81/opencart/");
			
			driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/']")).click();
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
			
			ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));
			
			// taking the input from the excel file using loop
			for(int i=1;i<row;i++)
			{
				
				XSSFCell mail=sheet.getRow(i).getCell(0);
				String mail_id=mail.toString();
				XSSFCell pw=sheet.getRow(i).getCell(1);
				String pwd=pw.toString();
				
			//clicking on my account then on login
			driver.findElement(By.xpath("//a[@href='http://10.207.182.111:84/opencart/index.php?route=account/login']")).click();

			//sending the inputs to user id and  password field from excel
			driver.findElement(By.xpath("//input[@name='email']")).sendKeys(mail_id);
			driver.findElement(By.name("password")).sendKeys(pwd);
			driver.findElement(By.xpath("//input[@type='submit']")).click();
			;
			
			//clicking on logout
			driver.findElement(By.xpath("//*[@href='http://10.207.182.111:84/opencart/index.php?route=account/logout']")).click();
			driver.findElement(By.xpath("//*[contains(text(),'Continue')]")).click();
			}
			
			wbook.close();
			driver.close();
		
		}
			

	}

